To OTA Updater start "OTA_Update.exe".

email: octanium91@gmail.com