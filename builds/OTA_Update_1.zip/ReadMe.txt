To OTA Updater start "otau.exe".

email: octanium91@gmail.com